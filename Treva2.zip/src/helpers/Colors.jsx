const Colors = {
    primary: '#F55A48',
    primaryBackground: 'linear-gradient(to right bottom, #F55A48, #fbb03b)',
    secondaryBackground: 'linear-gradient(to right bottom, #36B2DC, #0BD5B0)',
    secondary: '#0BD5B0',
    opacitySecondary: '#d9fcf6',
    white: '#ffffff',
    orange: '#F55A48',
    yellow: '#FBB03B',
    grey: '#dadada',
    grey1: '#B5B5B5',
    red: '#E50000',
    black: '#000000'
}

export default Colors