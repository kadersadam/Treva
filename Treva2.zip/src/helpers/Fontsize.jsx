const FontSize = {
    icons: '25px',
    iconCount: '10px',
    mdScreen: '13px',
    cartIcon: '20px',
    cardTitle: '16px'
}

export default FontSize