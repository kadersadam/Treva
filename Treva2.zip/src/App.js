import "bootstrap/dist/css/bootstrap.min.css";
import "./helpers/assests/Css/common.css";
// React Slick
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import "react-modern-drawer/dist/index.css";
import HomePage from "./components/HomePage/HomePage";

function App() {
  return (
    <div>
      <HomePage />
    </div>
  );
}

export default App;
